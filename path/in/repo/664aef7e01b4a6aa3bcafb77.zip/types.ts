
export interface ContainerProps {
  background?: string;
  padding?: string;
  dataCy?: string;
}

export interface NavbarProps {
  linkone?: string;
  linktwo?: string;
  linkthree?: string;
  logoname?: string;
  logoicon?: string;
  fontSize?: string;
  textColor?: string;
  backgroundColor?: string;
}
