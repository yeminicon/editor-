import React from "react";
      import { Route } from "@remix-run/react";
     

      import Container from "../components/files/Container"
import NavbarSample1 from "../components/files/NavbarSample1"
import CartSample1 from "../components/files/CartSample1"
import FooterSample1 from "../components/files/FooterSample1"
import ProductSample2 from "../components/files/ProductSample2"


     const CartPage : React.FC = () => {
           return (
            <div  className="p-5 mt-2 mx-auto w-[80%] max-w-[80%]">
                <div>

                <Container background="#eeeeee" padding="0" data-cy="root-container" />
<NavbarSample1 linkone="Home" linktwo="Service" linkthree="Contact" logoname="James" logoicon="" fontSize="" textColor="" backgroundColor="" />
<CartSample1  />
<FooterSample1  />
<ProductSample2  />

                </div>

               </div>
             )
      }
      export default  CartPage ;
      