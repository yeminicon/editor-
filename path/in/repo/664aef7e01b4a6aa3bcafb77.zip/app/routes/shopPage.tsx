import React from "react";
      import { Route } from "@remix-run/react";
     

      import Container from "../components/files/Container"
import NavbarSample1 from "../components/files/NavbarSample1"
import ProductSample1 from "../components/files/ProductSample1"
import ProductSample2 from "../components/files/ProductSample2"
import ProductSample1 from "../components/files/ProductSample1"
import BannerSample5 from "../components/files/BannerSample5"
import FooterSample1 from "../components/files/FooterSample1"


     const ShopPage : React.FC = () => {
           return (
            <div  className="p-5 mt-2 mx-auto w-[80%] max-w-[80%]">
                <div>

                <Container background="#eeeeee" padding="0" data-cy="root-container" />
<NavbarSample1 linkone="Home" linktwo="Service" linkthree="Contact" logoname="ACME" logoicon="" fontSize="" textColor="" backgroundColor="" />
<ProductSample1  />
<ProductSample2  />
<ProductSample1  />
<BannerSample5  />
<FooterSample1  />

                </div>

               </div>
             )
      }
      export default  ShopPage ;
      