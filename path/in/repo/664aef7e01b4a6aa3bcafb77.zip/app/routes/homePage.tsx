import React from "react";
      import { Route } from "@remix-run/react";
     

      import Container from "../components/files/Container"
import NavbarSample1 from "../components/files/NavbarSample1"
import BannerSample1 from "../components/files/BannerSample1"
import ProductSample1 from "../components/files/ProductSample1"
import FooterSample1 from "../components/files/FooterSample1"


     const HomePage : React.FC = () => {
           return (
            <div  className="p-5 mt-2 mx-auto w-[80%] max-w-[80%]">
                <div>

                <Container background="#eeeeee" padding="0" data-cy="root-container" />
<NavbarSample1 linkone="Home" linktwo="Service" linkthree="Contact" logoname="Emma" logoicon="" fontSize="" textColor="" backgroundColor="" />
<BannerSample1  />
<ProductSample1  />
<FooterSample1  />

                </div>

               </div>
             )
      }
      export default  HomePage ;
      