import React from "react";
      import { Route } from "@remix-run/react";
     

      


     const Default : React.FC = () => {
           return (
            <div  className="p-5 mt-2 mx-auto w-[80%] max-w-[80%]">
                <div>

                

                </div>

               </div>
             )
      }
      export default  Default ;
      