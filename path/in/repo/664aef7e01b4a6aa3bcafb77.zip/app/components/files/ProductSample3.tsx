

import { useState } from "react";
import { Image } from "@nextui-org/react";

const pl0 = "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/zr2cn0fvvdvworrxca0u"
const pl1 = "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/mvn2zvcmzapdvzu0yinb"
const pl2 = "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/qr5ecbfr03xhvbgmfpow"
const pl3 = "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/hvxyjuuibirwgwomiohd"
const pl4 = "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/rkpiljklpzod4qalpkdd"
const pl5 = "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/ktzcqryvl6yhslek5xl6"


const ListOfCategory = [
  {
    name: "Hollow Socks",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl0,
  },
  {
    name: "Glossier",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl1,
  },
  {
    name: "Darn Tough",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl2,
  },
  {
    name: "Invisasox",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl3,
  },
  {
    name: "Price $0",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl4,
  },
  {
    name: "Invisasox",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl5,
  },
  {
    name: "Price $0",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl4,
  },
];




 const ProductSample3 = () => {
  const [startIndex] = useState(0);
  const itemsPerPage = 5; // Number of items to display per page



  return (
    <div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
        <div className="p-4">
          <div className="flex flex-row justify-between">
            <h1 className="mx-auto font-bold text-1xl">Featured Collections</h1>
          </div>

          <div className="bg-white text-black p-6 md:w-[100%] w-[400px] flex flex-row overflow-hidden justify-between">
            {ListOfCategory.slice(startIndex, startIndex + itemsPerPage).map((cat) => (
              <div className="flex flex-col mr-3">
                     <div className="w-[12.5rem] h-[100%]">
                  <div className="w-[12.5rem] h-[20.5rem] rounded-t-lg">
                    <Image src={cat.pics} />
                  </div>
                  <div>
                    <h1 className="font-medium  text-center">{cat.name}</h1>
                    <div className="flex flex-col text-center">
                      <p className="font-bold">'$'{cat.price}</p>
                    </div>
                 
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="border w-[17rem] rounded-full mx-auto">
            <p className="mx-auto text-1xl text-center font-semibold">View All Collections</p>
          </div>
        </div>
      </div>
  );
};

export default ProductSample3;

