

import { Image } from "@nextui-org/react";

import { FaInstagram, FaLinkedin, FaTwitter } from "react-icons/fa";
import { FaFacebook } from "react-icons/fa6";
const navbarLogo =
  "https://res.cloudinary.com/dd2yns0fq/image/upload/f_auto,q_auto/v1/simple/template_1/components/logo/gcr63qvoibkjvqpy6dze";

const FooterSample3 = () => {
  const currentYear = new Date().getFullYear();

  return (
    <div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
      <div className="mt-5 p-4  bg-[#ffffff] w-full h-[100%] ">
        <div className="flex flex-row justify-between w-[95%] mx-auto">
          <div>
            <ul>
              <li className="font-bold">Company</li>
              <li className="font-light text-left text-[#9095AO]">About Us</li>
              <li className="font-light text-left text-[#9095AO]">Leadership</li>
              <li className="font-light text-left text-[#9095AO]">Blog</li>
              <li className="font-light text-left text-[#9095AO]">Careers</li>
              <li className="font-light text-left text-[#9095AO]">Referral Program</li>
              <li className="font-light text-left text-[#9095AO]">Community</li>
            </ul>
          </div>
          <div>
            <ul>
              <li className="font-bold">Support</li>
              <li className="font-light text-left text-[#9095AO]">Help centre</li>
              <li className="font-light text-left text-[#9095AO]">FAQ</li>
              <li className="font-light text-left text-[#9095AO]">Contact</li>
              <li className="font-light text-left text-[#9095AO]">Press</li>
              <li className="font-light text-left text-[#9095AO]">Status</li>
            </ul>
          </div>
          <div>
            <ul>
              <li className="font-bold">Shop</li>
              <li className="font-light text-left text-[#9095AO]">Apparel & Fashion</li>
              <li className="font-light text-left text-[#9095AO]">Health & Beauty</li>
              <li className="font-light text-left text-[#9095AO]">Food & Beverage</li>
              <li className="font-light text-left text-[#9095AO]">Manufacturing</li>
              <li className="font-light text-left text-[#9095AO]">Automotive</li>
            </ul>
          </div>
          <div>
            <ul>
              <li className="font-bold">Legal</li>
              <li className="font-light text-left text-[#9095AO]">Legal Notice</li>
              <li className="font-light text-left text-[#9095AO]">Privacy Policy</li>
              <li className="font-light text-left text-[#9095AO]">Terms of Use</li>
            </ul>
          </div>
        </div>
        <hr />
        <div className=" w-[95%] mx-auto flex flex-row justify-between h-[100%] bg-gray.100 m-auto">
          <div className="mt-4">
            <Image className="bg-[#0e2993]" src={navbarLogo} />
            <p>An e-commerce editor for sellers</p>
            <p className="mt-2 w-full text-center">
              &copy; {currentYear} Vendor. All Rights Reserved.
            </p>
          </div>
          <div className="flex flex-row mt-4">
            <FaFacebook color="#06218d" className="mx-1 " />
            <FaTwitter color="#06218d" className="mx-1 " />
            <FaInstagram color="#06218d" className="mx-1 " />
            <FaLinkedin color="#06218d" className="mx-1 " />
          </div>
        </div>
      </div>
      </div>
  );
};

export default FooterSample3;


