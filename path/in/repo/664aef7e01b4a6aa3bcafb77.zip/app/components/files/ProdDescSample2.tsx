
  
  import { Image } from "@nextui-org/react";

const pl4 =
  "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/rkpiljklpzod4qalpkdd";
const productData = [
  {
    img: pl4,
    name: "T-shirt",
    description:
      "Best in wears, fitted and elegant.  Best sow with italian masterpiece and a touch of Gold in leather silk. In various sizes for both genders and others. ",
    price: 500,
    note: "Available in all sizes",
  },
];
const ProdDescSample2 = () => {
  return (
    <div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
      <div className=" pb-5 flex w-[1000px] flex-col bg-white ">
        <div className="p-4">
          <div className="bg-white text-black p-6 md:w-[100%] w-[400px] flex flex-row overflow-hidden">
            {productData.map((data) => (
              <>
                <div className="flex flex-row">
                  <div className="flex-col">
                    <div className="w-[30rem] h-[18rem] flex flex-row">
                      <div className="w-[15.5rem] h-[16.875rem] rounded-t-lg">
                        <Image className="w-[15rem] h-[17rem]" src={data.img} />
                      </div>
                      <div className="w-[15.5rem] ml-4 h-[16.875rem] rounded-t-lg">
                        <Image className="w-[15rem] h-[17rem]" src={data.img} />
                      </div>
                    </div>
                    <div className="w-[30rem] h-[18rem] flex flex-row">
                      <div className="w-[15.5rem] h-[16.875rem] rounded-t-lg">
                        <Image className="w-[15rem] h-[17rem]" src={data.img} />
                      </div>
                      <div className="w-[15.5rem] ml-4 h-[16.875rem] rounded-t-lg">
                        <Image className="w-[15rem] h-[17rem]" src={data.img} />
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="ml-5 flex flex-col w-[20rem]">
                      <h1 className="font-bold text-1xl mb-1">{data.name}</h1>
                      <div className="flex flex-col mb-1">
                        <p className="mb-1">{data.note}</p>
                        <p className="font-bold text-1xl ">'$'{data.price}</p>
                      </div>
                      <div>
                        <p className=" mt-3 mb-2">Choose a Color</p>

                        <div className="flex flex-row mt-1">
                          <div className="w-8 h-8 bg-white border-1 rounded-full"></div>
                          <div className="w-8 h-8 bg-[#e06d94] border-1 rounded-full"></div>
                          <div className="w-8 h-8 bg-[#784576] border-1 rounded-full"></div>
                          <div className="w-8 h-8 bg-[#0c39ff] border-1 rounded-full"></div>
                          <div className="w-8 h-8 bg-[#65a4d0] border-1 rounded-full"></div>
                        </div>
                      </div>
                      <div>
                        <div className="my-3">
                          <h1 className="font-bold text-black mt-2">Assembly Note</h1>
                          <p>{data.description}</p>
                        </div>

                        <div className="w-full my-3 h-7 bg-[#1544ff] rounded-full">
                          <p className="text-white text-center font-bold mt-3">Add to Cart</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {/* <div className="mt-1">
                    <h1 className="font-bold text-black">Description</h1>
                    <p>{data.description}</p>
                  </div> */}
              </>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
export default ProdDescSample2;

  
  