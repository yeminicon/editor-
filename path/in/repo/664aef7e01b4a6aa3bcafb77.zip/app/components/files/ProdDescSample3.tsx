
  
  import {
    Button,
    Image,
    
  } from "@nextui-org/react";
  const pl4 =
    "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/rkpiljklpzod4qalpkdd";
  const productData = [
    {
      img: pl4,
      name: "T-shirt",
      description:
        "Best in wears, fitted and elegant.  Best sow with italian masterpiece and a touch of Gold in leather silk. In various sizes for both genders and others. ",
      price: 500,
      note: "Available in all sizes",
    },
  ];
  
  const ProdDescSample3 = () => {
    return (
      <div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
        <div className=" pb-5 flex w-[1000px] flex-col bg-white ">
          <div className="p-4  w-[750px] mx-auto">
            <div className="bg-white text-black p-6 md:w-[100%] w-[400px] flex flex-row overflow-hidden">
              {productData.map((data) => (
                <div className="flex flex-row">
                  <div className="w-[16rem] h-[100%]">
                    <div className="w-[16rem] h-[18.5rem] rounded-t-lg">
                      <Image src={data.img} />
                    </div>
                    <div className="flex flex-row w-[13.5rem] justify-between">
                      <div className="w-[2.8rem] h-[2rem]">
                        <Image className="w-[2.5rem] h-1.5rem]" src={data.img} />
                      </div>
                      <div className="w-[2.8rem] h-[2rem]">
                        <Image className="w-[2.5rem] h-1.5rem]" src={data.img} />
                      </div>
                      <div className="w-[2.8rem] h-[2rem]">
                        <Image className="w-[2.5rem] h-1.5rem]" src={data.img} />
                      </div>
                      <div className="w-[2.8rem] h-[2rem]">
                        <Image className="w-[2.5rem] h-1.5rem]" src={data.img} />
                      </div>
                    </div>
                  </div>
  
                  <div className="my-auto">
                    <div className=" flex flex-col mt-1">
                      <h1 className="font-bold m-1">{data.name}</h1>
                      <div className="flex flex-col mb-4">
                        <p className="font-bold ">'$'{data.price}</p>
                        <p className="w-[19rem]">{data.description}</p>
                      </div>
  
                      <div className="flex flex-row my-1">
                        <p className="font-bold">Model</p>
                        <p>#123345</p>
                      </div>
                      <div className="flex flex-row my-1">
                        <p className="font-bold">Color</p>
                        <p>#123345</p>
                      </div>
                      <div className="flex flex-row my-1">
                        <p className="font-bold">Quantity</p>
                        <p>#123345</p>
                      </div>
  
                      <div className="mt-3">
                        <div className="flex flex-row">
                          <Button className=" w-[10rem]" color="primary" variant="bordered">
                            Add to Cart
                          </Button>
                          <Button className="ml-3 w-[10rem]" color="primary" variant="solid">
                            Buy Now
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        </div>
    );
  };
  export default ProdDescSample3;
  
  
  