
import { Button, Image, Input } from "@nextui-org/react";
import { CiHeart, CiSearch, CiShoppingCart } from "react-icons/ci";
import { IoIosArrowDown } from "react-icons/io";
import { TbArrowsExchange } from "react-icons/tb";
import { NavbarProps } from "types";

const ListOfCategory = [
  { name: "Category" },
  { name: "Color" },
  { name: "Gender" },
  { name: "On sale" },
  { name: "Price $0" },
  { name: "Ratings" },
  { name: "Size" },
  { name: "Sort By" },
];

const NavbarSample1 = (props: NavbarProps) => {
  const navbarLogo =
    "https://res.cloudinary.com/dd2yns0fq/image/upload/f_auto,q_auto/v1/simple/template_1/components/logo/gcr63qvoibkjvqpy6dze";

  return (
    <div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
      <nav className="bg-white w-full mt-4">
        <div className="mx-auto max-w-[1000px] flex justify-between items-center">
          <div className="bg-[#4245d8] w-8 h-8 ml-2 font-bold rounded-full">
            <Image src={navbarLogo} className="mx-auto ml-1 mt-1" alt="navbarlogo" />
          </div>

          <Input
            startContent={<CiSearch />}
            size="sm"
            className="w-70"
            placeholder="socks"
          />

          <ul className="flex space-x-4 mr-3">
            <li>
              <CiHeart />
            </li>
            <li>
              <CiShoppingCart />
            </li>
            <li>
              <div className="w-[15px] h-[15px] rounded-full bg-[#F5F5F5] flex items-center justify-center">
                <p className="text-[0.5rem]">{props.logoname}</p>
              </div>
            </li>
          </ul>
        </div>

        <div className="mx-auto w-fit pt-4">
          <div className="flex flex-row pl-1 mt-3">
            <div className="w-[30px] h-[30px] rounded-full bg-[#F5F5F5] flex items-center justify-center">
              <TbArrowsExchange />
            </div>
            <div className="h-[30px] ml-2 flex items-center">
              {ListOfCategory.map((cat) => (
                <Button key={cat.name}  size="sm" className="ml-2" endContent={<IoIosArrowDown />}>
                  {cat.name}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default NavbarSample1;

