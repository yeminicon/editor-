

import { Image } from "@nextui-org/react";

const navbarLogo =
  "https://res.cloudinary.com/dd2yns0fq/image/upload/f_auto,q_auto/v1/simple/template_1/components/logo/gcr63qvoibkjvqpy6dze";

const FooterSample1 = () => {
  const currentYear = new Date().getFullYear();

  return (
    <div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
    <div className="mt-5 p-4  bg-[#ffffff] w-full h-[100%] ">
      <div className=" w-full flex flex-row justify-between h-[80px] bg-gray.100 m-auto">
        <div>
          <Image className="bg-[#0e2993] mt-5" src={navbarLogo} />
        </div>
        <div>
          <ul className="flex flex-row justify-between w-[300px]  mt-5">
            <li className="font-light text-left text-[#9095AO]">About</li>
            <li className="font-light text-left text-[#9095AO]">Contact</li>
            <li className="font-light text-left text-[#9095AO]">Demo Policy</li>
            <li className="font-light text-left text-[#9095AO]">Terms</li>
            <li className="font-light text-left text-[#9095AO]">Privacy</li>
          </ul>
        </div>

        <div>
          <p className="mt-5 w-full text-center">
            &copy; {currentYear} Vendor. All Rights Reserved.
          </p>
        </div>
      </div>
    </div>
  </div>
  );
};

export default FooterSample1;


