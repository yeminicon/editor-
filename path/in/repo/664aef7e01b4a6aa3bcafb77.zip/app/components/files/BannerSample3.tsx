
import { Image } from "@nextui-org/react";
const simple_Banner_2 =
"https://res.cloudinary.com/dd2yns0fq/image/upload/f_auto,q_auto/v1/simple/template_1/components/banner/vhdaqmigtt1zo0ek1no4";

const BannerSample3 = () => {
  return (
<div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
      <div className="w-[1000px] h-[100%]">
        <Image src={simple_Banner_2} />
      </div>
    </div>
  );
};

export default BannerSample3;

