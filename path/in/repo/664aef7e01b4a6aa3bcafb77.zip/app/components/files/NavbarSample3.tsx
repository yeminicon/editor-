
import { Image } from "@nextui-org/react";
import { CiSearch, CiShoppingCart } from "react-icons/ci";
import { Link } from "react-router-dom";
import { ImProfile } from "react-icons/im";
import { NavbarProps } from "types";

const NavbarSample3 = (props: NavbarProps) => {
  const navbarLogo =
    "https://res.cloudinary.com/dd2yns0fq/image/upload/f_auto,q_auto/v1/simple/template_1/components/logo/gcr63qvoibkjvqpy6dze";

  return (
    <div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
      <nav className="bg-white ">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex flex-row">
            <div className="bg-[#4245d8] ml-2 font-bold rounded-full">
              <Image src={navbarLogo} alt="navbarlogo" />
            </div>
          </div>
          <div className="w-[300px] ml-2 justify-between flex flex-row ">
            <Link to="">
              <p>Men</p>{" "}
            </Link>
            <Link to="">
              <p>Women</p>{" "}
            </Link>
            <Link to="">
              <p>Kids</p>{" "}
            </Link>
            <Link to="">
              <p>Home & Living</p>{" "}
            </Link>
          </div>
          <ul className="flex space-x-4 mr-3">
            <li>
              <ImProfile />
            </li>
            <li>
              <CiSearch />
            </li>
            <li>
              <CiShoppingCart />
            </li>
          </ul>
        </div>
      </nav>
    </div>
  );
};

export default NavbarSample3;

