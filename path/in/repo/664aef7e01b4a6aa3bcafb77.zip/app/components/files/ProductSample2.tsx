

import { useState } from "react";
import { Image } from "@nextui-org/react";
import { CiShoppingCart } from "react-icons/ci";

const pl0 = "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/zr2cn0fvvdvworrxca0u"
const pl1 = "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/mvn2zvcmzapdvzu0yinb"
const pl2 = "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/qr5ecbfr03xhvbgmfpow"
const pl3 = "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/hvxyjuuibirwgwomiohd"
const pl4 = "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/rkpiljklpzod4qalpkdd"
const pl5 = "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/ktzcqryvl6yhslek5xl6"


const ListOfCategory = [
  {
    name: "Hollow Socks",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl0,
  },
  {
    name: "Glossier",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl1,
  },
  {
    name: "Darn Tough",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl2,
  },
  {
    name: "Invisasox",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl3,
  },
  {
    name: "Price $0",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl4,
  },
  {
    name: "Invisasox",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl5,
  },
  {
    name: "Price $0",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl4,
  },
];




 const ProductSample2 = () => {
  const [startIndex] = useState(0);
  const itemsPerPage = 5; // Number of items to display per page



  return (
    <div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
    <div className="p-4">
      <div className="flex flex-row justify-between">
        <h1 className="p-2  font-bold text-1xl">Home & Living</h1>
      </div>

      <div className="bg-white text-black p-6 md:w-[100%] w-[400px] flex flex-row overflow-hidden justify-between" >
        {ListOfCategory.slice(startIndex, startIndex + itemsPerPage).map((cat) => (
          <div className="flex flex-col mr-3">
             <div className="w-[12.5rem] h-[100%]">
              <div className="w-[12.5rem] h-[20.5rem] rounded-t-lg">
                <Image src={cat.pics} />
              </div>
              <div>
                <h1 className="font-medium">{cat.name}</h1>
                <div className="flex flex-col">
                  <p className="">{cat.description}</p>
                  <p className="font-bold">'$'{cat.price}</p>
                </div>
                <div className="flex flex-row justify-between mt-3">
                  <div className="flex flex-row">
                    <div className="w-[30px] h-[30px]">
                      <Image width="30px" height="30px" src={cat.pics} />
                    </div>
                    <div className="mx-1 w-[30px] h-[30px]">
                      <Image width="30px" height="30px" src={cat.pics} />
                    </div>
                    <div className="w-[30px] h-[30px]">
                      <Image width="30px" height="30px" src={cat.pics} />
                    </div>
                 
                  </div>
                  <div className="w-8 h-4 rounded-lg text-black text-center text-sm font-medium bg-[#d6d7da]">
                      +3
                    </div>

                  <div className="flex justify-center align-middle place-content-center w-[25px] h-[25px] rounded-full bg-[#091a5f]">
                    <CiShoppingCart />
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div>
        <p className="mx-auto text-2xl font-semibold">Show more</p>
      </div>
    </div>
  </div>
  );
};

export default ProductSample2;

