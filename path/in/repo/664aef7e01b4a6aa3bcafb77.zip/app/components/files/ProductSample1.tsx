
import { useState } from "react";
import {
  MdOutlineKeyboardArrowLeft,
  MdOutlineKeyboardArrowRight,
} from "react-icons/md";
import { Image } from "@nextui-org/react";

const imageHref =
  "https://res.cloudinary.com/dm9lgej0j/image/upload/v1671341517/cld-sample-5.jpg";
const pl0 =
  "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/zr2cn0fvvdvworrxca0u";
const pl1 =
  "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/mvn2zvcmzapdvzu0yinb";
const pl2 =
  "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/qr5ecbfr03xhvbgmfpow";
const pl3 =
  "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/hvxyjuuibirwgwomiohd";
const pl4 =
  "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/rkpiljklpzod4qalpkdd";
const pl5 =
  "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/ktzcqryvl6yhslek5xl6";

const ListOfCategory = [
  {
    name: "Hollow Socks",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl0,
  },
  {
    name: "Glossier",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl1,
  },
  {
    name: "Darn Tough",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl2,
  },
  {
    name: "Invisasox",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl3,
  },
  {
    name: "Price $0",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl4,
  },
  {
    name: "Invisasox",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: pl5,
  },
  {
    name: "Price $0",
    rating: 4.2,
    description: "Best wears of all times",
    price: 25288,
    pics: imageHref,
  },
];

const ProductSample1 = () => {
  const [startIndex, setStartIndex] = useState(0);
  const itemsPerPage = 4;

  const nextPage = () => {
    setStartIndex((prev) =>
      Math.min(prev + itemsPerPage, ListOfCategory.length - itemsPerPage)
    );
  };

  const prevPage = () => {
    setStartIndex((prev) => Math.max(prev - itemsPerPage, 0));
  };

  return (
    <div className="flex flex-col items-center pb-5 w-[1000px] max-w-[1000px] mx-auto mt-5">
      <div className="p-4 w-full max-w-[1000px]">
        <div className="flex justify-between items-center mb-4">
          <h1 className="font-bold text-xl">Men's Clothing</h1>
          <div className="flex space-x-4">
            <div
              className="w-8 h-8 rounded-full bg-gray-500 flex items-center justify-center cursor-pointer"
              onClick={prevPage}
            >
              <MdOutlineKeyboardArrowLeft color="#fff" />
            </div>
            <div
              className="w-8 h-8 rounded-full bg-gray-500 flex items-center justify-center cursor-pointer"
              onClick={nextPage}
            >
              <MdOutlineKeyboardArrowRight color="#fff" />
            </div>
          </div>
        </div>

        <div className="flex space-x-4 overflow-hidden">
          {ListOfCategory.slice(startIndex, startIndex + itemsPerPage).map(
            (cat) => (
              <div
                key={cat.name}
                className="flex flex-col bg-white text-black p-4 rounded-lg"
              >
                <div className="w-[200px] h-[328px]">
                  <Image
                    src={cat.pics}
                    alt={cat.name}
                    width="100%"
                    height="328px"
                  />
                </div>
                <h2 className="font-medium mt-2">{cat.name}</h2>
                <p className="mt-1">{cat.description}</p>
                <p className="font-bold mt-1">{cat.price}</p>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductSample1;

