
import { Image } from "@nextui-org/react";

import { FaInstagram, FaLinkedin, FaTwitter } from "react-icons/fa";
import { FaFacebook } from "react-icons/fa6";
const navbarLogo =
  "https://res.cloudinary.com/dd2yns0fq/image/upload/f_auto,q_auto/v1/simple/template_1/components/logo/gcr63qvoibkjvqpy6dze";

const FooterSample5 = () => {
  return (
    <div className="pb-5 flex bg-[#F5F6FA] w-[1000px] mx-auto flex-col pt-4">
      <div className=" w-full flex flex-col h-[80px] bg-gray.100 m-auto">
        <div className="mx-auto">
          <Image src={navbarLogo} />
        </div>
        <div className="mx-auto">
          <ul className="flex flex-row">
            <li className="font-light text-left text-[#9095AO]">About</li>
            <li className="font-light text-left text-[#9095AO]">Contact</li>
            <li className="font-light text-left text-[#9095AO]">Demo Policy</li>
            <li className="font-light text-left text-[#9095AO]">Terms</li>
            <li className="font-light text-left text-[#9095AO]">Privacy</li>
          </ul>
        </div>

        <div className="mx-auto">
          <div className="flex flex-row">
            <FaFacebook className="bg-[#06218d]" />
            <FaTwitter />
            <FaInstagram />
            <FaLinkedin />
          </div>
        </div>
      </div>
    </div>
  );
};

export default FooterSample5;

