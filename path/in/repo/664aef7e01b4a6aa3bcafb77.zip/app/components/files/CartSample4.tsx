

import { Button, Image,  Link } from "@nextui-org/react";
import { BiMinus, BiPlus } from "react-icons/bi";
import { MdCancel } from "react-icons/md";
const imageHref = "https://res.cloudinary.com/dm9lgej0j/image/upload/v1671341517/cld-sample-5.jpg";


  const cartItems = [
     {
       id: 1,
       img: imageHref,
       name: "T-shirt",
       description:
         "Best in wears, fitted and elegant.  Best sow with italian masterpiece and a touch of Gold in leather silk. In various sizes for both genders and others. ",
       price: 5000,
       quantity: 10,
       note: "Available in all sizes",
       countInStock: "3",
     },
     {
       id: 1,
       img: imageHref,
       name: "T-shirt",
       description:
         "Best in wears, fitted and elegant.  Best sow with italian masterpiece and a touch of Gold in leather silk. In various sizes for both genders and others. ",
       price: 5000,
       quantity: 10,
       note: "Available in all sizes",
       countInStock: "3",
     },
   ];


const CartSample4 = () => {
  
  return (
    <div className=" pb-5 flex w-[1000px] flex-col bg-white ">
    <div className="p-4">
      <h1 className="font-bold text-2xl my-3">Shopping Bag</h1>
      <p>1 Items</p>
      <div className="mt-2 flex flex-row justify-between bg-white text-black p-6 md:w-[100%] w-[400px] border-1 rounded-lg  overflow-hidden">
        <div className="w-[70%]">
          {cartItems.map((item) => (
            <>
              <div className="mt-3" key={item.id}>
                <div className="flex flex-row justify-between">
                <div className="flex flex-row ">
                    <Image src={item.img} alt={item.name} className="w-16 h-16 mx-2" />
                    <div>
                      <Link>{item.name}</Link>
                      <p>{item.note}</p>
                      <div className="mb-3 mt-1 flex flex-row w-20 justify-center h-7 border-1 rounded-lg">
                        {" "}
                      <BiMinus className="mt-1 mr-1" />
                        <span>{item.quantity}</span>{" "}
                     
                      <BiPlus className="mt-1 ml-1" />
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col">
                    <MdCancel />
                    <div>'$'{item.price}</div>
                  </div>
                </div>
              </div>
              <hr />
            </>
          ))}
        </div>
        <div className="w-[200px] h-[200px]">
          <h1 className="font-bold mb-3">Order Summary</h1>
          <div className="flex flex-row mt-1 justify-between">
            <p className="font-medium ">Product price</p>
            <p>$15000</p>
          </div>
          <hr />
          <div className="flex flex-row mt-1 justify-between">
            <p className="font-medium ">Home delivery</p>
            <p>$1500</p>
          </div>
          <hr />
          <div className="flex flex-row mt-1 justify-between">
            <p className="font-medium ">Total</p>
            <p>$16500</p>
          </div>
         

          <Button color="primary" className="rounded-lg mt-4">
            Continue to Checkout
          </Button>
        </div>
      </div>
    </div>
  </div>
  );
};

export default CartSample4;


