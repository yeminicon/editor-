
import {
  Image,
  Table,
  TableBody,
  TableCell,
  TableColumn,
  TableHeader,
  TableRow,
} from "@nextui-org/react";
import { FaMinus, FaPlus } from "react-icons/fa";

const pl4 =
  "https://res.cloudinary.com/dm9lgej0j/image/upload/f_auto,q_auto/v1/editorProduct/rkpiljklpzod4qalpkdd";
const productData = [
  {
    img: pl4,
    name: "T-shirt",
    description:
      "Best in wears, fitted and elegant.  Best sow with italian masterpiece and a touch of Gold in leather silk. In various sizes for both genders and others. ",
    price: 500,
    note: "Available in all sizes",
  },
];
const ProdDescSample1 = () => {
  return (
    <div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
      <div className=" pb-5 flex w-[1000px] flex-col bg-white ">
        <div className="p-4">
          <div className="bg-white text-black p-6 md:w-[100%] w-[400px] flex flex-row overflow-hidden">
            {productData.map((data) => (
              <div className="flex flex-row justify-center">
                <div className="w-[25.5rem] h-[21.875rem] ">
                  <div className="w-[18.5rem] h-[21.5rem] rounded-t-lg float-end">
                    <Image
                      className="w-[18.5rem] h-[21.5rem] rounded-t-lg "
                      src={data.img}
                    />
                  </div>
                </div>

                <div className=" w-[25.5rem] h-[21.875rem] ">
                  <div className="ml-5 flex flex-col w-[20rem]">
                    <h1 className="font-bold">{data.name}</h1>
                    <div className="flex flex-col">
                      <p>{data.note}</p>
                      <p className="font-bold">5000</p>
                    </div>

                    <div>
                      <Table
                        removeWrapper
                        aria-label="Example static collection table"
                      >
                        <TableHeader>
                          <TableColumn>""</TableColumn>
                          <TableColumn>""</TableColumn>
                        </TableHeader>
                        <TableBody>
                          <TableRow key="1">
                            <TableCell>Type</TableCell>
                            <TableCell>Cotton</TableCell>
                          </TableRow>
                          <TableRow key="2">
                            <TableCell> Size</TableCell>
                            <TableCell>42</TableCell>
                          </TableRow>
                          <TableRow key="3">
                            <TableCell>Quantity</TableCell>
                            <TableCell>
                              <div className="flex flex-row">
                                <FaMinus />
                                1
                                <FaPlus />
                              </div>
                            </TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>

                      <div className="w-full my-1 h-4 bg-[#1240f7]">
                        <p className="text-white text-center text-[0.65rem]">
                          Add to Cart
                        </p>
                      </div>

                      <div className="w-full my-1 h-4 bg-[#c5cef7]">
                        <p className="text-[#031763] text-center text-[0.65rem]">
                          Buy Now
                        </p>
                      </div>

                      <div>
                        <h1 className="font-bold text-black">Description</h1>
                        <p>{data.description}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProdDescSample1;

