

import { Button, Image,  Link } from "@nextui-org/react";
const imageHref = "https://res.cloudinary.com/dm9lgej0j/image/upload/v1671341517/cld-sample-5.jpg";


  const cartItems = [
     {
       id: 1,
       img: imageHref,
       name: "T-shirt",
       description:
         "Best in wears, fitted and elegant.  Best sow with italian masterpiece and a touch of Gold in leather silk. In various sizes for both genders and others. ",
       price: 5000,
       quantity: 10,
       note: "Available in all sizes",
       countInStock: "3",
     },
     {
       id: 1,
       img: imageHref,
       name: "T-shirt",
       description:
         "Best in wears, fitted and elegant.  Best sow with italian masterpiece and a touch of Gold in leather silk. In various sizes for both genders and others. ",
       price: 5000,
       quantity: 10,
       note: "Available in all sizes",
       countInStock: "3",
     },
   ];


const CartSample1 = () => {
  const updateCartHandler = async (quantity: number) => {
  
    console.log(quantity);
  };
  return (
    <div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
      <div className="p-4">
        <h1 className="font-bold text-2xl my-3">Shopping Bag</h1>
        <div className=" flex flex-row justify-between bg-white text-black p-6 md:w-[100%] w-[400px] border-1 rounded-lg  overflow-hidden">
          <div className="w-[70%]">
            {cartItems.map((item) => (
              <>
                <div className="" key={item.id}>
                  <div className="flex flex-row justify-between mb-2">
                    <div className="flex flex-row ">
                      <Image src={item.img} alt={item.name} className="w-16 h-16 mx-2" />
                      <div>
                        <Link>{item.name}</Link>
                        <p>{item.note}</p>
                      </div>
                    </div>
                    <div className="flex flex-row">
                      <div>'$'{item.price}</div>
                      <Button
                        onClick={() => updateCartHandler(item.quantity - 1)}
                        variant="light"
                        disabled={item.quantity === 1}
                      >
                        <i className="fas fa-minus-circle"></i>
                      </Button>{" "}
                      <span>{item.quantity}</span>{" "}
                      <Button variant="light" onClick={() => updateCartHandler(item.quantity + 1)}>
                        <i className="fas fa-plus-circle"></i>
                      </Button>
                    </div>
                  </div>
                </div>
                <hr className="mb-3" />
              </>
            ))}
          </div>
          <div className="w-[20%] h-[100%]">
            <div className="flex flex-row justify-between">
              <p className="font-bold ">Sub Total</p>
              <p>$15000</p>
            </div>

            <Button className="mt-4" color="primary">
              Continue to Checkout
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartSample1;


