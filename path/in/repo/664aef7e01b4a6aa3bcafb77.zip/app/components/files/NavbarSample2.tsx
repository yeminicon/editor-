
import { Input, Image } from "@nextui-org/react";
import { CiHeart, CiSearch, CiShoppingCart } from "react-icons/ci";
import { Link } from "react-router-dom";
import { NavbarProps } from "types";

const NavbarSample2 = (props: NavbarProps) => {
  const navbarLogo =
    "https://res.cloudinary.com/dd2yns0fq/image/upload/f_auto,q_auto/v1/simple/template_1/components/logo/gcr63qvoibkjvqpy6dze";

  return (
    <div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
      <nav className="bg-white w-full mt-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex flex-row">
            <div className="bg-[#4245d8] ml-2 font-bold rounded-full">
              <Image src={navbarLogo} alt="navbarlogo" />
            </div>
            <div className="w-[300px] ml-2 justify-between flex flex-row ">
              <Link to="">
                <p>Men</p>{" "}
              </Link>
              <Link to="">
                <p>Women</p>{" "}
              </Link>
              <Link to="">
                <p>Kids</p>{" "}
              </Link>
              <Link to="">
                <p>Home & Living</p>{" "}
              </Link>
            </div>
          </div>
          <div>
            <Input
              startContent={<CiSearch />}
              size="sm"
              className="w-70"
              placeholder="Search here..."
            />
          </div>
          <ul className="flex space-x-4 mr-3">
            <li>
              <CiHeart />
              <p>profile</p>
            </li>
            <li>
              <CiShoppingCart />
              <p>Cart</p>
            </li>
            <li>
              <div className="w-[15px] h-[15px]  rounded-full bg-[#F5F5F5] flex align-middle justify-center ">
                <p className="text-[0.5rem]">{props.logoname}</p>
              </div>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  );
};

export default NavbarSample2;

