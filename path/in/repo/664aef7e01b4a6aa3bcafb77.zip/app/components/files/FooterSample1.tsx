

import { Image } from "@nextui-org/react";

import { FaInstagram, FaLinkedin, FaTwitter } from "react-icons/fa";
import { FaFacebook } from "react-icons/fa6";
const navbarLogo =
  "https://res.cloudinary.com/dd2yns0fq/image/upload/f_auto,q_auto/v1/simple/template_1/components/logo/gcr63qvoibkjvqpy6dze";

const FooterSample1 = () => {
  const currentYear = new Date().getFullYear();

  return (
    <div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
      <div className="mt-5 p-4  bg-[#ffffff] w-full h-[100%] ">
        <div className="flex flex-row justify-between w-[95%] mx-auto">
          <div>
            <Image className="bg-[#0e2993]" src={navbarLogo} />
            <p className="text-[0.65rem]">An e-commerce editor for sellers</p>
          </div>
          <div>
            <ul>
              <li className="font-bold">Company</li>
              <li className="font-light text-[0.65rem] text-left text-[#9095AO]">About Us</li>
              <li className="font-light text-[0.65rem] text-left text-[#9095AO]">Stores</li>
              <li className="font-light text-[0.65rem] text-left text-[#9095AO]">Categories</li>
              <li className="font-light text-[0.65rem] text-left text-[#9095AO]">Contact</li>
            </ul>
          </div>
          <div>
            <ul>
              <li className="font-bold">Legal</li>
              <li className="font-light text-[0.65rem] text-left text-[#9095AO]">Legal Notice</li>
              <li className="font-light text-[0.65rem] text-left text-[#9095AO]">Privacy Policy</li>
              <li className="font-light text-[0.65rem] text-left text-[#9095AO]">Terms of Use</li>
            </ul>
          </div>
          <div>
            <ul>
              <li className="font-bold">Follow us</li>
              <li className="flex flex-row">
                <FaFacebook className="mx-1" />
                <FaTwitter className="mx-1" />
                <FaInstagram className="mx-1" />
                <FaLinkedin className="mx-1" />
              </li>
            </ul>
          </div>
        </div>
        <hr className="mt-9" />
        <div className=" w-full flex h-[80px] bg-gray.100 m-auto">
          <p className="mt-3 w-full text-center">
            &copy; {currentYear} Vendor. All Rights Reserved.
          </p>
        </div>
      </div>
    </div>
  );
};

export default FooterSample1;

