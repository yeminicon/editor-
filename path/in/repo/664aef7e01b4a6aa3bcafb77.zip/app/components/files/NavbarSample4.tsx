
import { Image, Input } from "@nextui-org/react";
import { CiSearch, CiShoppingCart } from "react-icons/ci";
import { Link } from "react-router-dom";
import { ImProfile } from "react-icons/im";
import { NavbarProps } from "types";

const NavbarSample4 = (props: NavbarProps) => {
  const navbarLogo =
    "https://res.cloudinary.com/dd2yns0fq/image/upload/f_auto,q_auto/v1/simple/template_1/components/logo/gcr63qvoibkjvqpy6dze";

  return (
    <div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
      <nav className="bg-white ">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex flex-row">
            <div className="bg-[#4245d8] ml-2 font-bold rounded-full">
              <Image src={navbarLogo} alt="navbarlogo" />
            </div>
          </div>
          <div>
            <div className="w-[300px] ml-2 justify-between flex flex-row ">
              <Link to="">
                <p className="text-white">Men</p>{" "}
              </Link>
              <Link to="">
                <p className="text-white">Women</p>{" "}
              </Link>
              <Link to="">
                <p className="text-white">Kids</p>{" "}
              </Link>
              <Link to="">
                <p className="text-white">Home & Living</p>{" "}
              </Link>
            </div>
          </div>

          <Input
            startContent={<CiSearch />}
            size="sm"
            className="w-70"
            placeholder="socks"
          />
          <ul className="flex space-x-4 mr-3">
            <li>
              <ImProfile color="white" />
            </li>
            <li>
              <CiSearch color="white" />
            </li>
            <li>
              <CiShoppingCart color="white" />
            </li>
          </ul>
        </div>
      </nav>
    </div>
  );
};

export default NavbarSample4;

