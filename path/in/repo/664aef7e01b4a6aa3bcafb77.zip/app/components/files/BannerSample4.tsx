
import { Image } from "@nextui-org/react";
const simple_Banner_3 =
"https://res.cloudinary.com/dd2yns0fq/image/upload/f_auto,q_auto/v1/simple/template_1/components/banner/srycbiu6tlolzzhjdyum";

const BannerSample4 = () => {
  return (
<div className="pb-5 flex w-[1000px] mx-auto flex-col pt-4">
      <div className="w-[1000px] h-[100%]">
        <Image src={simple_Banner_3} />
      </div>
    </div>
  );
};

export default BannerSample4;

