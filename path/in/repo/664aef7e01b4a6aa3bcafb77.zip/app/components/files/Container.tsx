
import React from 'react'
import { NavbarProps } from "types";


const Container = (props: NavbarProps) => {
  return (
    <></>
  )
}

export default Container
