
import { Input, Image } from "@nextui-org/react";
import { CiSearch, CiShoppingCart } from "react-icons/ci";
import navbarLogo from "@/assets/navbarLogo.svg";
import { Link } from "react-router-dom";
import { BsPerson } from "react-icons/bs";
import { NavbarProps } from "types";

const NavbarSample5 = (props: NavbarProps) => {
  return (
    <div className=" py-5 my-5 flex w-[100%] flex-col">
      <nav className="bg-white ">
        <div className="w-full h-[4rem]">
          <li className="flex flex-row justify-end">
            <p>Hey! {props.logoname}</p>
            <BsPerson className="mt-1 ml-1" />
          </li>
        </div>
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex flex-row">
            <div className="bg-[#d1d1f1] ml-2 font-bold rounded-full">
              <Image src={navbarLogo} alt="navbarlogo" />
            </div>
          </div>
          <div className="flex flex-row">
            <div className="w-[300px] ml-2 justify-between flex flex-row ">
              <Link to="">
                <p>Men</p>{" "}
              </Link>
              <Link to="">
                <p>Women</p>{" "}
              </Link>
              <Link to="">
                <p>Kids</p>{" "}
              </Link>
              <Link to="">
                <p>Home & Living</p>{" "}
              </Link>
            </div>
          </div>
          <div>
            <Input
              startContent={<CiSearch />}
              size="sm"
              className="w-70"
              placeholder="Search here..."
            />
          </div>
          <ul className="flex space-x-4 mr-3">
            <li>
              <CiShoppingCart />
            </li>
          </ul>
        </div>
      </nav>
    </div>
  );
};

export default NavbarSample5;

